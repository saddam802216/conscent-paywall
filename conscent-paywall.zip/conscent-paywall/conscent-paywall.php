<?php
/*
 * Plugin Name:       Conscent Paywall
 * Plugin URI:        https://conscent.ai/
 * Description:       Conscent.ai is the world’s fastest-growing advanced analytics and revenue optimization solution for the media and news publishing industry.
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Version:           2.0.0
 * Author:            conscent.ai
 * Author URI:        https://conscent.ai/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain:       conscent-paywall
 * Domain Path:       /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define global variables...

define( 'CONSCENT_PAYWALL_NAME', 'ConsCent Paywall for WordPress' );
define( 'CONSCENT_PAYWALL_SLUG', 'conscent-paywall' );
define( 'CONSCENT_PAYWALL_VERSION', '2.0.0' );
define( 'CONSCENT_PAYWALL_URL', plugin_dir_url( __FILE__ ) );
define( 'CONSCENT_PAYWALL_PATH', plugin_dir_path( __FILE__ ) );
define( 'CONSCENT_PAYWALL_BASENAME', plugin_basename( __FILE__ ) );
define( 'CONSCENT_PAYWALL_REL_DIR', dirname( CONSCENT_PAYWALL_BASENAME ) );

if ( ! defined( 'CONSCENT_CLIENT_ID' ) ) {

	define( "CONSCENT_CLIENT_ID", sanitize_text_field( wp_unslash( get_option('conscent_client_id') ) ) );

}

if ( ! defined( 'CONSCENT_SDK_URL' ) ) {
	
	define( "CONSCENT_SDK_URL", esc_url( get_option('conscent_sdk_url') ) );

}

if ( ! defined( 'CONSCENT_API_URL' ) ) {
	
	define( "CONSCENT_API_URL", esc_url( get_option('conscent_api_url') ) );

}

if ( ! defined( 'CONSCENT_API_KEY' ) ) {
	
	define( "CONSCENT_API_KEY", sanitize_text_field( wp_unslash( get_option('conscent_api_key') ) ) );

}

if ( ! defined( 'CONSCENT_API_SECRET' ) ) {
	
	define( "CONSCENT_API_SECRET", sanitize_text_field( wp_unslash( get_option('conscent_api_secret') ) ) );

}

if ( ! defined( 'CONSCENT_CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT' ) ) {
	
	define( "CONSCENT_CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT", 2 );

}

if ( ! defined( 'CONSCENT_AMP_SDK_URL' ) ) {

	define( "CONSCENT_AMP_SDK_URL", esc_url( get_option('conscent_amp_sdk_url') ) );
	
}

if ( ! defined( 'CONSCENT_AMP_API_URL' ) ) {
	
	define( "CONSCENT_AMP_API_URL", esc_url( get_option('conscent_amp_api_url') ) );

}

register_uninstall_hook( __FILE__, 'conscent_uninstall' );

/**
 * Runs on plugin uninstallation.
 * Cleans up any metadata related to the plugin.
 */
if ( ! function_exists( 'conscent_uninstall' ) ) {
	function conscent_uninstall() {
		global $wpdb;
		// Delete custom meta keys
		delete_post_meta_by_key( 'conscent_price' );
		delete_post_meta_by_key( 'conscent_duration' );
	}
}

/**
 * Enqueue styles for front-end.
 */
if ( ! function_exists( 'conscent_plugin_enqueue_styles' ) ) {
	function conscent_plugin_enqueue_styles() {
		wp_enqueue_style( 'conscent-style-css', CONSCENT_PAYWALL_URL . 'assets/css/style.css', array(), CONSCENT_PAYWALL_VERSION );
	}
}
add_action( 'admin_enqueue_scripts', 'conscent_plugin_enqueue_styles' );

// Include necessary files.
require_once CONSCENT_PAYWALL_PATH . 'conscent-function.php';
require_once CONSCENT_PAYWALL_PATH . 'conscent-login-function.php';
require_once CONSCENT_PAYWALL_PATH . 'admin/conscent-sections.php';
require_once CONSCENT_PAYWALL_PATH . 'admin/conscent-metabox.php';
require_once CONSCENT_PAYWALL_PATH . 'admin/conscent-setting.php';