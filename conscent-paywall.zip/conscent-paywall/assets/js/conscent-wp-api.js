const conscent_client_id = conscentData.conscent_client_id;
const conscent_sdk_url = conscentData.conscent_sdk_url;

(function (w, d, s, o, f, cid) {
    if (!w[o]) {
        w[o] = function () {
            w[o].q.push(arguments);
        };
        w[o].q = [];
    }
    (js = d.createElement(s)), (fjs = d.getElementsByTagName(s)[0]);
    js.id = o;
    js.src = f;
    js.async = 1;
    js.title = cid;
    fjs.parentNode.insertBefore(js, fjs);
})(window, document, 'script', '_csc', conscent_sdk_url, conscent_client_id);

const csc = window._csc;
var contentId = conscentData.conscent_content_id;
csc('show');
csc('init', {
	debug: true, // can be set to false to remove sdk non-error log output
	contentId: contentId,
	clientId: conscent_client_id,
	title: conscentData.conscent_content_title,
	categories: conscentData.conscent_content_category,
	tags:  conscentData.conscent_content_tags,
	sections: conscentData.conscent_content_sections,
	authorName: conscentData.conscent_content_author,
	successCallback: yourSuccessCallbackFunction,
	wrappingElementId: 'csc-paywall',
	fullScreenMode: 'false' // if set to true, the entire screen will be covered,
});

async function yourSuccessCallbackFunction(validationObject) {
    const conscent_api_url = conscentData.conscent_api_url;
    const conscent_api_key = conscentData.conscent_api_key;
    const conscent_api_secret = conscentData.conscent_api_secret;
    const conscent_post_content = conscentData.conscent_post_content;
    const consumptionId = validationObject.consumptionId;
    const checkConsumptionURL = `/content/consumption/${consumptionId}`;
    const url = `${conscent_api_url}${checkConsumptionURL}`;

    // Define the data to send in JSON format
    const postData = JSON.stringify({
        consumptionId: consumptionId
    });

    // Make the POST request using fetch
    fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa(`${conscent_api_key}:${conscent_api_secret}`)
        },
        body: postData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        console.log('Response :', response);
        return response.json(); // Parse JSON response
    })
    .then(data => {
        if (
            data.consumptionId === consumptionId &&
            data.payload.contentId === contentId &&
            data.payload.clientId === conscent_client_id
        ) {
            jQuery('#conscent_content').empty().html(`${conscent_post_content}`);
        }

        console.log('Response Data:', data); // Handle the data received
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
}