// Define Conscent client ID
const conscent_login_client_id = conscentLoginData.conscent_client_id;
const conscent_login_sdk_url = conscentLoginData.conscent_sdk_url;

(function (w, d, s, o, f, cid) {
    if (!w[o]) {
        w[o] = function () {
            w[o].q.push(arguments);
        };
        w[o].q = [];
    }
    (js = d.createElement(s)), (fjs = d.getElementsByTagName(s)[0]);
    js.id = o;
    js.src = f;
    js.async = 1;
    js.title = cid;
    fjs.parentNode.insertBefore(js, fjs);
})(window, document, 'script', '_csc', conscent_login_sdk_url, conscent_login_client_id);

const subsLogOut = function() {
    const cscLogout = window._csc;
    cscLogout('logout');
}

const subsLogin = function() {
    document.querySelector("#loginOverlay").style.display = "block";
    const cscLogin = window._csc;
    cscLogin('login-with-redirect');
}

const userdetailspage = () => {
    console.log('Navigating to User Details Page');
    const cscUserDetail = window._csc;
    cscUserDetail('open-user-details-page', {
        onSuccess: (data) => {
            console.log(data);
        },
        wrappingElementId: 'users',
    });
};

document.addEventListener("DOMContentLoaded", function() {
    const cscLogin = window._csc;
    cscLogin('add-auth-state-listener', (userId) => {
        const conscentLoginLogoutClasses = document.getElementsByClassName("conscent-login-logout");
        if(userId) {
            const hasConscentLogin = conscentLoginLogoutClasses[0].querySelector(".conscent-login") !== null;
            for (let i = 0; i < conscentLoginLogoutClasses.length; i++) {
                conscentLoginLogoutClasses[i].innerHTML = '<a href="#" class="conscent-logout" onclick="subsLogOut();" target="_parent">Logout</a>';
                conscentLoginLogoutClasses[i].insertAdjacentHTML("beforebegin", '<li class="conscent-userdetail"><a href="#" onclick="userdetailspage();" target="_parent">User Detail</a></li>');
            }
            if (hasConscentLogin) {
                location.reload();
            }
        }else {
            for (let i = 0; i < conscentLoginLogoutClasses.length; i++) {
                conscentLoginLogoutClasses[i].innerHTML = '<a href="#" class="conscent-login" onclick="subsLogin();" target="_parent">Login</a>';
            }
        }
    });
});