<?php

/**
 * The conscent setting create a setting page in WordPress admin panel.
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'conscent_settings_page' ) ) {

	function conscent_settings_page() {

?>

	<div class="wrap">
		
		<div class="container">

			<h1><?php esc_html_e( 'Conscent Setting', 'conscent-paywall' ); ?> </h1>
			<hr />
			<div class="row">

				<div class="col-8 col-md-8">

					<form method="post" action="options.php">

						<?php
									   
							settings_fields("conscent_settings_section");

							do_settings_sections("conscent_paywall_general_settings");      

							submit_button(); 

						?>          

					</form>

				</div>

			</div>

		</div>

	</div>

<?php

	}

}

if ( ! function_exists( 'conscent_setting_description' ) ) {

	function conscent_setting_description() {

		echo '<h4>' . esc_html__( 'Manage and configure your Conscent integration effortlessly.', 'conscent-paywall' ) . '</h4>';
	}

}


if ( ! function_exists( 'conscent_theme_menu_item' ) ) {

	function conscent_theme_menu_item() {

		add_menu_page("Conscent Setting", "Conscent Setting", "manage_options", "conscent-paywall", "conscent_settings_page", null, 99);

	}

}

add_action("admin_menu", "conscent_theme_menu_item");


if ( ! function_exists( 'conscent_client_id_element' ) ) {

	function conscent_client_id_element() {

	?>

		<input 
			type="text" 
			class="form-control regular-text" 
			name="conscent_client_id" 
			id="conscent_client_id" 
			value="<?php echo esc_attr(get_option('conscent_client_id')); ?>" 
			placeholder="<?php esc_attr_e('Enter your Client ID', 'conscent-paywall'); ?>"
			aria-describedby="clientIdHelp"
		/>
		<p class="help-block">
			<?php esc_html_e('Enter your conscent client ID here.', 'conscent-paywall'); ?>
		</p>

		<?php

	}

}

if ( ! function_exists( 'conscent_sdk_element' ) ) {

	function conscent_sdk_element() {

	?>

		<input 
			type="text" 
			class="form-control regular-text" 
			name="conscent_sdk_url" 
			id="conscent_sdk_url" 
			value="<?php echo esc_url(get_option('conscent_sdk_url')); ?>" pattern="https://.*" 
			placeholder="<?php esc_attr_e('Enter your SDK URL', 'conscent-paywall'); ?>"
			title="<?php esc_attr_e('The URL should start with https://', 'conscent-paywall'); ?>" 
			aria-describedby="sdkUrlHelp" 
		/>

		<p class="help-block">
			<?php echo esc_url('https://conscent-sdk-v2-sandbox.netlify.app/csc-sdk.js'); ?>
			| 
			<?php echo esc_url('https://sdk-v2.conscent.in/csc-sdk.js'); ?>
		</p>

		<?php

	}

}

if ( ! function_exists( 'conscent_paywall_category_element' ) ) {

	function conscent_paywall_category_element() {
	?>

		<select 
			class="form-control" 
			name="conscent_paywall_category" 
			id="conscent_paywall_category" 
			aria-describedby="paywallHelp"
		>
			<option value=""><?php esc_html_e('Select options', 'conscent-paywall'); ?></option>
			<?php 
			$categories = get_categories(); 
			foreach ($categories as $category) {
				$option_value = esc_attr($category->term_id);
				$option_text = esc_html($category->cat_name . ' (' . $category->category_count . ')');
				$selected = ($category->term_id == get_option('conscent_paywall_category')) ? 'selected' : '';
			?>
				<option value="<?php echo esc_attr( $option_value ); ?>" <?php echo esc_attr( $selected ); ?>>
					<?php echo esc_html( $option_text ); ?>
				</option>
			<?php } ?>
		</select>
		<p class="help-block"><?php esc_html_e('Choose a category for your paywall settings.', 'conscent-paywall'); ?></p>
	<?php

	}

}

if ( ! function_exists( 'conscent_api_url_element' ) ) {

	function conscent_api_url_element() {
	?>

		<input 
			type="url" 
			class="form-control regular-text" 
			name="conscent_api_url" 
			id="conscent_api_url" 
			value="<?php echo esc_url( get_option('conscent_api_url') ); ?>" 
			placeholder="<?php esc_attr_e('Enter your API URL', 'conscent-paywall'); ?>" 
			pattern="https://.*" 
			title="<?php esc_attr_e('The URL should start with https://', 'conscent-paywall'); ?>" 
			required 
		/>

		<p class="help-block">
			<?php echo esc_url('https://sandbox-api.conscent.in/api/v2'); ?>
			|
			<?php echo esc_url('https://api.conscent.in/api/v2'); ?>
		</p>

	<?php

	}

}

if ( ! function_exists( 'conscent_api_key_element' ) ) {

	function conscent_api_key_element() {

	?>

		<input 
			type="text" 
			class="form-control regular-text" 
			name="conscent_api_key" 
			id="conscent_api_key" 
			value="<?php echo esc_attr(sanitize_key(get_option('conscent_api_key'))); ?>" 
			placeholder="<?php esc_attr_e('Enter your API key', 'conscent-paywall'); ?>" 
			aria-describedby="apiKeyHelp" 
		/>

		<p class="help-block">
			<?php esc_html_e('Please ensure that your API key is kept private.', 'conscent-paywall'); ?>
		</p>

		<?php

	}

}

if ( ! function_exists( 'conscent_api_secret_element' ) ) {

	function conscent_api_secret_element() {

	?>

		<input 
			type="password" 
			class="form-control regular-text" 
			name="conscent_api_secret" 
			id="conscent_api_secret" 
			value="<?php echo esc_attr(get_option('conscent_api_secret')); ?>" 
			placeholder="<?php esc_attr_e('Enter your API secret', 'conscent-paywall'); ?>" 
			aria-describedby="apiSecretHelp" 
		/>
		<p class="help-block">
			<?php esc_html_e('Keep this secret confidential and do not share it publicly.', 'conscent-paywall'); ?>
		</p>

	<?php

	}

}

if ( ! function_exists( 'conscent_after_logout_element' ) ) {

	function conscent_after_logout_element() {

	?>

		<input 
			type="text" 
			class="form-control regular-text" 
			name="conscent_after_logout" 
			id="conscent_after_logout"
			value="<?php echo esc_url(get_option('conscent_after_logout')); ?>"
			placeholder="<?php esc_attr_e('Enter the URL to redirect after logout', 'conscent-paywall'); ?>" 
		/>
		<p class="help-block">
			<?php esc_html_e('Enter the URL where users should be redirected after logout', 'conscent-paywall'); ?>
		</p>

	<?php

	}

}

if ( ! function_exists( 'conscent_after_login_redirect_element' ) ) {

	function conscent_after_login_redirect_element() {

	?>
		<input 
			type="text" 
			class="form-control regular-text" 
			name="conscent_after_login" 
			id="conscent_after_login" 
			value="<?php echo esc_url(get_option('conscent_after_login')); ?>" 
			placeholder="<?php esc_attr_e('Enter the URL to redirect after login', 'conscent-paywall'); ?>"
		/>
		<p class="help-block">
			<?php esc_html_e('Enter the URL where users should be redirected after logging in.', 'conscent-paywall'); ?>
		</p>
	
	<?php
	}

}

if ( ! function_exists( 'conscent_theam_location_element' ) ) {

	function conscent_theam_location_element() {

		// Begin the select element with the default option
		echo '<select class="form-control" name="conscent_theme_location" id="conscent_theme_location">
		<option value="">' . esc_html__('Select Theme Location', 'conscent-paywall') . '</option>';

		// Get available theme locations
		$theme_locations = get_nav_menu_locations();

		// Iterate over each theme location and output the options
		foreach ($theme_locations as $theme_location => $menu_id) {
		// Check if the current option is selected
		$selected = selected(sanitize_text_field(get_option('conscent_theme_location')), $theme_location, false);

		// Output each option securely
		echo '<option value="' . esc_attr($theme_location) . '" ' . esc_attr( $selected ) . '>' . esc_html($theme_location) . '</option>';
		}

		// Close the select element
		echo '</select>';
		
	}
	
}


if ( ! function_exists( 'conscent_content_visibility_element' ) ) {

	function conscent_content_visibility_element() {

	?>

		<input 
			type="number" 
			class="form-control regular-text" 
			name="conscent_content_visibility" 
			id="conscent_content_visibility" 
			value="<?php echo esc_attr( get_option('conscent_content_visibility') ); ?>" 
			placeholder="<?php esc_attr_e('Enter the number of paragraphs visible in locked content', 'conscent-paywall'); ?>" 
			min="1" 
			step="1" 
			title="<?php esc_attr_e('Please enter a positive number.', 'conscent-paywall'); ?>" 
		/>

		<p class="help-block"> <?php esc_html_e('Number of paragraphs to be visible in locked content', 'conscent-paywall'); ?></p>


	<?php

	}

}

if ( ! function_exists( 'conscent_default_name_element' ) ) {

	function conscent_default_name_element() {

	?>

		<select class="form-control" name="conscent_default_name" id="conscent_default_name">
			<option value="0" <?php selected(sanitize_text_field(get_option('conscent_default_name')), '0'); ?>>
				<?php esc_html_e('Select Option', 'conscent-paywall'); ?>
			</option>
			
			<option value="1" <?php selected(get_option('conscent_default_name'), '1'); ?>>
				<?php esc_html_e('User Name', 'conscent-paywall'); ?>
			</option>
			
			<option value="2" <?php selected(get_option('conscent_default_name'), '2'); ?>>
				<?php esc_html_e('User Mobile', 'conscent-paywall'); ?>
			</option>
			
			<option value="3" <?php selected(get_option('conscent_default_name'), '3'); ?>>
				<?php esc_html_e('User Email ID', 'conscent-paywall'); ?>
			</option>
		</select>

	<?php

	}

}

if( ! function_exists( 'conscent_amp_sdk_url_element' ) ) {

	function conscent_amp_sdk_url_element () {
 
?>
		<input 
			type="url" 
			class="form-control regular-text" 
			name="conscent_amp_sdk_url" 
			id="conscent_amp_sdk_url" 
			value="<?php echo esc_url( get_option('conscent_amp_sdk_url') ); ?>" 
			placeholder="<?php esc_attr_e('Enter the Conscent AMP SDK URL', 'conscent-paywall'); ?>" 
			pattern="https://.*" 
			title="<?php esc_attr_e('The URL should start with https://', 'conscent-paywall'); ?>" 
		/>

		<p class="help-block">
			<?php echo esc_url( 'https://v2-amp-sdk-sandbox.netlify.app' ); ?> | <?php echo esc_url( 'https://sdk-amp-v2.conscent.in/csc-sdk.js' ); ?>
		</p>

<?php

	}

}

if( ! function_exists( 'conscent_amp_api_url_element' ) ) {

	function conscent_amp_api_url_element () {
 
?>
		<input 
			type="url" 
			class="form-control regular-text" 
			name="conscent_amp_api_url" 
			id="conscent_amp_api_url" 
			value="<?php echo esc_url( get_option('conscent_amp_api_url') ); ?>" 
			placeholder="<?php esc_attr_e('Enter the Conscent AMP API URL', 'conscent-paywall'); ?>" 
			pattern="https://.*" 
			title="<?php esc_attr_e('The URL should start with https://', 'conscent-paywall'); ?>"  
		/>

		<p class="help-block">
			<?php echo esc_url('https://sandbox-api.conscent.in/api/v2'); ?>
			| <?php echo esc_url('https://api.conscent.in/api/v2'); ?>
		</p>
<?php

	}

}

if ( ! function_exists( 'conscent_theme_panel_fields' ) ) {

	function conscent_theme_panel_fields() {

		add_settings_section("conscent_settings_section", "All Settings", "conscent_setting_description", "conscent_paywall_general_settings");

		add_settings_field("conscent_client_id", "Conscent Client Id", "conscent_client_id_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_api_key", "Conscent API Key <br>(Sandbox OR Live)", "conscent_api_key_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_api_secret", "Conscent API Secret (Sandbox OR Live)", "conscent_api_secret_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_sdk_url", "Conscent SDK URL (Sandbox OR Live)", "conscent_sdk_element", "conscent_paywall_general_settings", "conscent_settings_section");
		
		add_settings_field("conscent_api_url", "Conscent API URL (Sandbox OR Live)", "conscent_api_url_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_amp_sdk_url", "Conscent AMP SDK URL (Sandbox OR Live)", "conscent_amp_sdk_url_element", "conscent_paywall_general_settings", "conscent_settings_section");
		
		add_settings_field("conscent_amp_api_url", "Conscent AMP API URL (Sandbox OR Live)", "conscent_amp_api_url_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_paywall_category", "Paywall Category", "conscent_paywall_category_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_after_logout", "After Logout Redirect", "conscent_after_logout_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_after_login",  "After Login Redirect URL", "conscent_after_login_redirect_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_theme_location","Theme Location Name", "conscent_theam_location_element", "conscent_paywall_general_settings", "conscent_settings_section");
		
		add_settings_field("conscent_content_visibility","Content Visibility", "conscent_content_visibility_element", "conscent_paywall_general_settings", "conscent_settings_section");

		add_settings_field("conscent_default_name","Default Name", "conscent_default_name_element", "conscent_paywall_general_settings", "conscent_settings_section");

		register_setting("conscent_settings_section", 
						 "conscent_paywall_category", 
						 array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						));

		register_setting("conscent_settings_section", 
						 "conscent_client_id", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						));
		
		register_setting("conscent_settings_section", 
						 "conscent_api_key", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						));

		register_setting("conscent_settings_section", 
						 "conscent_api_secret", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						));

		register_setting("conscent_settings_section", 
						 "conscent_sdk_url", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));

		register_setting("conscent_settings_section", 
						 "conscent_api_url", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));

		register_setting("conscent_settings_section", 
						 "conscent_amp_sdk_url", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));
		
		register_setting("conscent_settings_section", 
						 "conscent_amp_api_url", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));

		register_setting("conscent_settings_section", 
						 "conscent_after_logout", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));

		register_setting("conscent_settings_section", 
						 "conscent_after_login", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						));

		register_setting("conscent_settings_section", 
						 "conscent_theme_location", 
						 array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						));

		register_setting("conscent_settings_section", 
						 "conscent_content_visibility", 
						 array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						));

		register_setting("conscent_settings_section", 
						 "conscent_default_name", 
						 array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						));

	}

}

add_action("admin_init", "conscent_theme_panel_fields");