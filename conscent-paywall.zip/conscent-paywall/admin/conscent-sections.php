<?php

/**
 * Add taxomony as sections
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'conscent_register_taxonomy_sections' ) ) {

	function conscent_register_taxonomy_sections() {
		$labels = array(
			'name'              => _x('Conscent Sections', 'taxonomy general name', 'conscent-paywall'),
			'singular_name'     => _x('Conscent Section', 'taxonomy singular name', 'conscent-paywall'),
			'search_items'      => __('Search Conscent Sections', 'conscent-paywall'),
			'all_items'         => __('All Conscent Sections', 'conscent-paywall'),
			'parent_item'       => __('Parent Conscent Section', 'conscent-paywall'),
			'parent_item_colon' => __('Parent Conscent Section:', 'conscent-paywall'),
			'edit_item'         => __('Edit Conscent Section', 'conscent-paywall'),
			'update_item'       => __('Update Conscent Section', 'conscent-paywall'),
			'add_new_item'      => __('Add New Conscent Section', 'conscent-paywall'),
			'new_item_name'     => __('New Conscent Section Name', 'conscent-paywall'),
			'menu_name'         => __('Conscent Sections', 'conscent-paywall'),
		);
	
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'conscent-sections' ),
		);
	
		register_taxonomy('conscent_sections', 'post', $args);
	}
	
}
add_action( 'init', 'conscent_register_taxonomy_sections' );
?>