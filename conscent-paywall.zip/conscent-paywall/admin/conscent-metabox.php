<?php

/**
 * Add meta data to post and save it to each post save or update.
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'conscent_member_add_meta_box' ) ) {

    function conscent_member_add_meta_box() {
        //this will add the metabox for the member post type
        $screens = array('post');
        foreach ($screens as $screen) {
            add_meta_box('conscent_visibility_post_meta', esc_html__('Content Visibility', 'conscent-paywall'), 'conscent_content_visibility_meta_box_callback', $screen);
        }
    }

}
add_action('add_meta_boxes', 'conscent_member_add_meta_box');
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
if ( ! function_exists( 'conscent_content_visibility_meta_box_callback' ) ) {

    function conscent_content_visibility_meta_box_callback($post) {
        // Add a nonce field so we can check for it later.
        wp_nonce_field('conscent_member_save_meta_box_data', 'member_meta_box_nonce');
        /*

    * Use get_post_meta() to retrieve an existing value

    * from the database and use the value for the form.

    */
        $value = sanitize_text_field( get_post_meta($post->ID, 'conscent_post_content_visibility', true) );
        echo '<label for="Content Visibility">' . esc_html__('Content Visibility(in Paragraph)', 'conscent-paywall') . '</label> ';
        echo '<input type="text" id="conscent_post_content_visibility" name="conscent_post_content_visibility" value="' . esc_attr($value) . '" size="25" />';
    }

}
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */

 if ( ! function_exists( 'conscent_member_save_meta_box_data' ) ) {

    function conscent_member_save_meta_box_data($post_id) {
        
        // Verify nonce for security
        if (!isset($_POST['member_meta_box_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['member_meta_box_nonce'])), 'conscent_member_save_meta_box_data')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check the user's permissions.
        if ( isset($_POST['post_type']) && 'page' == sanitize_text_field(wp_unslash($_POST['post_type'])) ) {
            if (!current_user_can('edit_page', $post_id)) {
                return;
            }
        } else {
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        }
        
        // Save the content visibility data
        if (isset($_POST['conscent_post_content_visibility'])) {
            $conscent_post_content_visibility = sanitize_text_field(wp_unslash($_POST['conscent_post_content_visibility']));
            update_post_meta($post_id, 'conscent_post_content_visibility', esc_attr($conscent_post_content_visibility));
        }
    }

}
add_action('save_post', 'conscent_member_save_meta_box_data');
?>