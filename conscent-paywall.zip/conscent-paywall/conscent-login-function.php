<?php

/**
 * All helper functions used with Conscent Login like conscent login, google login, google one tap.
 * Display login, logout and user details button with menu.
 * 
 * @package Conscent Paywall
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conscent login initialization script.
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */

if ( ! function_exists( 'conscent_enqueue_scripts_login_init' ) ) {

    function conscent_enqueue_scripts_login_init() {
        // Enqueue the JavaScript file
        wp_enqueue_script(
            'conscent-login-script',
            CONSCENT_PAYWALL_URL . 'assets/js/conscent-wp-login.js',
            ['jquery'], // Dependencies
            CONSCENT_PAYWALL_VERSION,
			true // Load in the footer
        );
        // Pass PHP variables to JavaScript
        wp_localize_script('conscent-login-script', 'conscentLoginData', [
			'conscent_client_id' => sanitize_text_field( wp_unslash(CONSCENT_CLIENT_ID) ),
            'conscent_sdk_url' => esc_url(CONSCENT_SDK_URL),
        ]);
    }
}
add_action('wp_enqueue_scripts', 'conscent_enqueue_scripts_login_init');

if ( ! function_exists( 'conscent_add_users_div_to_body' ) ) {
	/**
		 * Adds a custom user overlay and user container div to the footer of the page.
		 * 
		 * This function outputs a hidden overlay div for login and a separate div
		 * for user details. The overlay is initially hidden and can be toggled 
		 * using JavaScript when login or other user interactions are required.
		 */
	function conscent_add_users_div_to_body() {
		// Prepare HTML with sanitized output
		$overlay_html = '
            <div id="conscent-overlay-wrapper">
                <div id="loginOverlay" role="dialog" aria-hidden="true" style="position: fixed; z-index: 99999; top: 40px; left: 0px; right: 0px; display: none;">
                    <div class="container-fluid">
                        <div class="row custom-row">
                            <div class="col-md-12">
                                <div id="csc-login"></div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
            <div id="users"></div>';

		// Output sanitized HTML
		echo wp_kses_post( $overlay_html );
	}
}
add_action('wp_footer', 'conscent_add_users_div_to_body');

/*
	 * Add Login Logout Menu Item to navigation at given theme location from admin
	 * 
	 * */

add_filter( 'wp_nav_menu_items', 'conscent_login_logout_menu_link', 10, 2 );

if ( ! function_exists( 'conscent_login_logout_menu_link' ) ) {

	/**
		 * Adds a custom login/logout link to the specified menu location.
		 *
		 * @param string $items The HTML list content for the menu items.
		 * @param object $args  An object containing wp_nav_menu() arguments.
		 * @return string Modified menu items.
		 */

	function conscent_login_logout_menu_link( $items, $args ) {
		$menu_theme_location = sanitize_text_field( get_option('conscent_theme_location', 'primary_menu') );

		if( isset( $args->theme_location ) && $args->theme_location === $menu_theme_location) {

			$items .= '<li class="conscent-login-logout"></li>';

		}

		return $items;

	}
}


if ( ! function_exists( 'conscent_login_button' ) ) {
	/**
		 * Renders a login button with a JavaScript click handler.
		 */
	function conscent_login_button() {
		echo '<a href="#" class="conscent-login" onclick="subsLogin();" target="_parent">'.esc_html__( 'Login', 'conscent-paywall' ).'</a>';
	}
}

if ( ! function_exists( 'conscent_logout_button' ) ) {
	/**
		 * Renders a logout button with a JavaScript click handler.
		 */
	function conscent_logout_button() {
		echo '<a href="#" class="conscent-logout" onclick="subsLogOut();" target="_parent">'.esc_html__( 'Logout', 'conscent-paywall' ).'</a>';
	}
}

if ( ! function_exists( 'conscent_user_detail_button' ) ) {
	/**
		 * Renders a user details popup with a JavaScript click handler.
		 */
	function conscent_user_detail_button() {
		echo '<li class="conscent-userdetail"><a href="#" onclick="userdetailspage();" target="_parent">' . esc_html__( 'User Detail', 'conscent-paywall' ) . '</a></li>';
	}
}