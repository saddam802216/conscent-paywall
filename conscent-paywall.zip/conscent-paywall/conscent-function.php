<?php
/**
 * All helper functions used with Conscent Paywall
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'conscent_prefix_insert_after_paragraph' ) ) {

    function conscent_prefix_insert_after_paragraph( $insertion, $paragraph_id, $content ) {

        $closing_p = '</p>';
        $paragraphs = explode( $closing_p, $content );

        foreach ($paragraphs as $index => $paragraph) {
            if ( trim( $paragraph ) ) {
                $paragraphs[$index] .= $closing_p;
            }
            if ( $paragraph_id == $index + 1 ) {
                $paragraphs[$index] .= $insertion;
            }
        }

        return implode( '', $paragraphs );

    }
}

/*
 *
 * Return array of content between locked and unlocked content  
 * 0 index is unlocked content i.e a part of content that should be displated 
 * 1 index is remaining part of content
 * 
 */ 
if ( ! function_exists( 'conscent_get_short_content' ) ) {

    function conscent_get_short_content($content) {
        global $wpdb;
		
		// Get number of paragraphs to be shown if content is locked
		$content_visibility = absint( get_option('conscent_content_visibility') );

		// Fetch the Conscent data using get_post_meta
		$conscent_post_content_visibility = absint(get_post_meta(get_the_ID(), 'conscent_post_content_visibility', true));

        // Determine visible content based on meta data or default settings
        $visible_content = !empty( $conscent_post_content_visibility ) ? $conscent_post_content_visibility :
        (!empty( $content_visibility ) ? $content_visibility : 
        ( defined( 'CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT' ) ? CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT : 2 ));

        // Add string after visible content ( by default it is two paragraph ) 
        $development_tag = 'Coderwolves';

        // make content after add infix "Coderwolves" into content 
        $content_with_infix = conscent_prefix_insert_after_paragraph( $development_tag, $visible_content, $content );
        $processed_content = explode($development_tag, $content_with_infix);
        return $processed_content;
    }

}

/**
 * This method is called on the_content filter hook and handle the locked and unlocked 
 * condition 
 * addConscentPayWall
 * Adds the ConsCent Pay Wall
 * @param type $content
 * @return string
 */

if ( ! function_exists( 'conscent_add_conscent_paywall' ) ) {

    function conscent_add_conscent_paywall($content) {
        
        if ( is_single() && 'post' == get_post_type() ) {
            $post_content_parts = conscent_get_short_content($content);
			
			// get post content after locked the content 
            $locked_content = (!empty($post_content_parts[0])) ? $post_content_parts[0] : '';
			
			// Apply filter to make content with consent paywall wrapper and element to load conscent paywall
            $conscent_paywall_locked_content = '<div id="conscent_content">' . $locked_content . '<span id="conscent-loader"> </span></div><div id="csc-paywall"></div>';
            return wp_kses_post( $conscent_paywall_locked_content );
        } else {
            return $content;
        }
    }
 
}

add_filter('the_content', 'conscent_add_conscent_paywall');

/**
 * Embeds supported URLs in post content using oEmbed.
 *
 * @param string $post_content The post content potentially containing URLs.
 * @return string Modified post content with embedded URLs.
 */
if ( ! function_exists( 'conscent_embed_code' ) ) {
    
    function conscent_embed_code($post_content) {

        // Regular expression to match URLs
        $url_pattern = '/(ht|f)tps?:\/\/[^"]*?(?=<|\s|$)/';

        // Find all URLs in the content
        preg_match_all($url_pattern, $post_content, $matches);

        // Define supported sites for embedding
        $supported_sites = array('youtube.com', 'youtu.be', 'twitter.com', 'facebook.com', 'linkedin.com', 'instagram.com', 'xing.com');

        // Loop through the matched URLs
        foreach ($matches[0] as $url) {

            foreach ($supported_sites as $site) {
                if (strpos($url, $site) !== false) {
                    // Embed the URL and replace it within the content
                    $embed_html = wp_oembed_get($url);
                    if ($embed_html) {
                        $post_content = str_replace($url, $embed_html, $post_content);
                    }
                    break;
                }
            }
            
        }
        // Output the modified post content
        return wpautop( $post_content );
    }

}

/**
 * Conscent paywall initialization API.
 *
 * @package Conscent Paywall
 * @since 2.0.0
 */


if ( ! function_exists( 'conscent_enqueue_scripts_journey_api' ) ) {

    function conscent_enqueue_scripts_journey_api() {
		if ( !is_single() || 'post' !== get_post_type() ) return;
        // Enqueue the JavaScript file
        wp_enqueue_script(
            'conscent-api-script',
            CONSCENT_PAYWALL_URL . 'assets/js/conscent-wp-api.js',
            ['jquery'], // Dependencies
            CONSCENT_PAYWALL_VERSION,
            true // Load in the footer
        );

        global $post;
        $post_content = conscent_embed_code($post->post_content);
        $author_id     = absint( get_post_field ('post_author', $post->ID) );
        $display_name  = get_the_author_meta( 'first_name' , $author_id );
        
        // Get tags
        $tags = get_the_tags($post->ID);
        $tags_list = $tags ? wp_list_pluck($tags, 'name') : [];
        $tags_json = wp_json_encode($tags_list);

        // Get categories
        $categories = get_the_category($post->ID);
        $cat_name_array = $categories ? wp_list_pluck($categories, 'cat_name') : [];
        $cat_name_json = wp_json_encode($cat_name_array);

        // Get sections and merge with categories
        $sections_names = wp_get_object_terms($post->ID, 'conscent_sections', ['fields' => 'names']);
        $merge_sections_names = array_merge($sections_names ?: [], $cat_name_array);

        // Trim spaces from merged section names
        $trimmed_sections_names = array_map('trim', $merge_sections_names);
        $sectionslist_json = wp_json_encode($trimmed_sections_names);
        

        // Pass PHP variables to JavaScript
        wp_localize_script('conscent-api-script', 'conscentData', [
            'conscent_api_url'    => esc_url( CONSCENT_API_URL ),
            'conscent_api_key'    => sanitize_text_field( wp_unslash(CONSCENT_API_KEY) ),
            'conscent_api_secret' => sanitize_text_field( wp_unslash(CONSCENT_API_SECRET) ),
            'conscent_post_content' => $post_content, // For the current post
            'conscent_client_id' => sanitize_text_field( wp_unslash(CONSCENT_CLIENT_ID) ),
            'conscent_sdk_url' => esc_url(CONSCENT_SDK_URL),
            'conscent_content_id' => absint( $post->ID ),
            'conscent_content_title' => sanitize_text_field( $post->post_title ),
            'conscent_content_category' => sanitize_text_field( $cat_name_json ),
            'conscent_content_tags' => sanitize_text_field( $tags_json ),
            'conscent_content_sections' => sanitize_text_field( $sectionslist_json ),
            'conscent_content_author' => sanitize_text_field( wp_unslash($display_name) ),
        ]);
    }

}
add_action('wp_enqueue_scripts', 'conscent_enqueue_scripts_journey_api');